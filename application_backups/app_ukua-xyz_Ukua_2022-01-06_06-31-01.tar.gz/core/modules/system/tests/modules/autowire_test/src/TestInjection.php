<?php

namespace Drupal\autowire_test;

/**
 * A service that is autowired.
 */
class TestInjection implements TestInjectionInterface {
}
