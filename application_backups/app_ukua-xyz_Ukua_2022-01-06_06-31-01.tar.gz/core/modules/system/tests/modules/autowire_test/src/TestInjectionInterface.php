<?php

namespace Drupal\autowire_test;

/**
 * An interface for a service that is autowired.
 */
interface TestInjectionInterface {
}
