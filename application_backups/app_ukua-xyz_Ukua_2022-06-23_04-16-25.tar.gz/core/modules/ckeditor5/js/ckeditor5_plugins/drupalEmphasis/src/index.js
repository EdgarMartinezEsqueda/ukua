// cspell:ignore drupalemphasis

import DrupalEmphasis from './drupalemphasis';

/**
 * @private
 */
export default {
  DrupalEmphasis,
};
